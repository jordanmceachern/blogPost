import React from 'react'
import './hamburger.css'

const hamburger = () => {
    return(
        <div id="hamburger">
            <hr />
            <hr />
            <hr />
        </div>
    )
}

export default hamburger